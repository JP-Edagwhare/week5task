
//jscript for meter to other unit conversion

document.getElementById('meter-submit').addEventListener('click', ()=>{
    event.preventDefault();
    let convMeter = document.getElementById('meter-input').value;
    
    document.getElementById('meter-inches').value = convMeter * 39.370;
    document.getElementById('meter-feet').value = convMeter * 3.281;
    document.getElementById('meter-yard').value = convMeter * 1.094;
});

//reset button for meter conversion

document.getElementById('meter-reset').addEventListener('click', ()=>{
    event.preventDefault();
    let convMeter = document.getElementById('meter-input').value = document.getElementById('meter-input').innerHTML;
    
    document.getElementById('meter-inches').value = convMeter;
    document.getElementById('meter-feet').value = convMeter;
    document.getElementById('meter-yard').value = convMeter;
});

//js for INCHES to Feet, Yard and Meter

document.getElementById('inches-submit').addEventListener('click', ()=>{
    event.preventDefault();
    let convInch = document.getElementById('inches-input').value;
    
    document.getElementById('inches-feet').value = convInch * 0.833;
    document.getElementById('inches-yard').value = convInch * 0.028;
    document.getElementById('inches-meter').value = convInch / 39.37;
});


//reset button for inches conversion

document.getElementById('inches-reset').addEventListener('click', ()=>{
    event.preventDefault();
    let convInch = document.getElementById('inches-input').value = document.getElementById('inches-input').innerHTML;
    
    document.getElementById('inches-feet').value = convInch;
    document.getElementById('inches-yard').value = convInch;
    document.getElementById('inches-meter').value = convInch;
});

//js for FEET to Yard, Meter and Inches

document.getElementById('feet-submit').addEventListener('click', function(){
    event.preventDefault();

    let convFeet = document.getElementById('feet-input').value;

    document.getElementById('feet-yard').value = convFeet * 0.33;
    document.getElementById('feet-meter').value = convFeet / 3.281;
    document.getElementById('feet-inches').value = convFeet * 12;
})

//reset button for feet conversion

document.getElementById('feet-reset').addEventListener('click', function(){
    event.preventDefault();

    let convFeet = document.getElementById('feet-input').value = document.getElementById('feet-input').innerHTML;
    
    document.getElementById('feet-yard').value = convFeet;
    document.getElementById('feet-meter').value = convFeet;
    document.getElementById('feet-inches').value = convFeet;
})

// js for YARD to Meter, Inches and Feet conversion

document.getElementById('yard-submit').addEventListener('click', function (){
    event.preventDefault();

    let convYard = document.getElementById('yard-input').value;

    document.getElementById('yard-meter').value = convYard / 1.094;
    document.getElementById('yard-inches').value = convYard * 36;
    document.getElementById('yard-feet').value = convYard * 3;
})

// Reset button for Yard conversion

document.getElementById('yard-reset').addEventListener('click', function(){
    event.preventDefault();

    let convYard = document.getElementById('yard-input').value = document.getElementById('yard-input').innerHTML;

    document.getElementById('yard-meter').value = convYard;
    document.getElementById('yard-inches').value = convYard;
    document.getElementById('yard-feet').value = convYard;
})

// End of script one

//Script two for single unit converter

//Javascript to convert meter to other unit

const unit = document.querySelector("#m");

unit.addEventListener("input", conv);
function conv(e) {
  let meter = e.target.value;

  document.getElementById("i").value = meter * 39.2;
  document.getElementById("f").value = meter * 10;
  document.getElementById("y").value = meter * 20;
}

//Javascript to convert inches to other unit

const unit1 = document.querySelector("#i");
unit1.addEventListener("input", conv1);
function conv1(e) {
  let inches = e.target.value;

  document.getElementById("f").value = inches * 39.2;
  document.getElementById("y").value = inches * 10;
  document.getElementById("m").value = inches * 20;
}

//Javascript to convert feet to other unit

const unit2 = document.querySelector("#f");
unit2.addEventListener("input", conv2);
function conv2(e) {
  let feet = e.target.value;

  document.getElementById("y").value = feet * 39.2;
  document.getElementById("m").value = feet * 10;
  document.getElementById("i").value = feet * 20;
}

//Javascript to convert yard to other unit

const unit3 = document.querySelector("#y");
unit3.addEventListener("input", conv3);
function conv3(e) {
  let yard = e.target.value;

  document.getElementById("m").value = yard * 39.2;
  document.getElementById("i").value = yard * 10;
  document.getElementById("f").value = yard * 20;
}

//Reset button - clear all

const resetBtn = document.querySelector("#reset");

resetBtn.addEventListener("click", function () {
  clearAll = document.querySelector("input");

  document.getElementById("m").value = clearAll;
  document.getElementById("i").value = clearAll;
  document.getElementById("f").value = clearAll;
  document.getElementById("y").value = clearAll;
});