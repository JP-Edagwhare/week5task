function instruction() {
    let a = `
    READ THE FOLLOWING INSTRUCTIONS CAREFULLY.
    
    1.  First name and Last name must not be the same.

    2.  First and last name must be between 8 - 12 characters.

    3.  User name must include one special character and at 
         least one number.

    4.  Password must be between 6 and 8 characters.

    5.  All fields MUST be filled.
             `
    alert(a);
}

const fnameValidation = document.getElementById('fname');
const lnameValidation = document.getElementById('lname');
const pwdValidation = document.getElementById('pwd1');
const pwdValidation1 = document.getElementById('pwd2');

const submitBtn = document.querySelector('#submitBtn');

submitBtn.addEventListener('click', function validate (event){
    

    if (fnameValidation.value === lnameValidation.value) {
        alert("First Name and Last name must not be the same.")
        event.preventDefault();
    }
    if (pwdValidation.value !== pwdValidation1.value){
        alert('Password did not match')
        event.preventDefault();
    }
    else {event.submit();
    }
})


